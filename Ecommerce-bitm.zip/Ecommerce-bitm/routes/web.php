<?php

Route::get('/', [
    'uses'  => 'NewShopController@index',
    'as'    => '/'
]);
Route::get('/category-product', [
    'uses'  => 'NewShopController@categoryProduct',
    'as'    => 'category-product'
]);
Route::get('/mail', [
    'uses'  => 'NewShopController@mail',
    'as'    => 'mail'
]);